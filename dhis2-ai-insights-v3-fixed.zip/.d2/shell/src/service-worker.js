import { setUpServiceWorker } from '@dhis2/pwa'

setUpServiceWorker()
