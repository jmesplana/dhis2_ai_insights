const config = {
    type: 'app',
    title: 'AI Insights',
    name: 'AI Insights',
    description: 'An AI-powered analytics tool that enables natural language querying of DHIS2 health data. Users can ask questions in plain language to analyze trends, identify patterns, and generate insights from aggregate, event, and tracker data. Features include conversational data analysis, automated visualizations, and report generation across multiple organization units and time periods.',
    entryPoints: {
        app: './src/App.jsx',
    },
    minDhisVersion: '2.35',
    authorities: []
}

module.exports = config
